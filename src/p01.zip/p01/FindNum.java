package p01;

import java.util.Random;
import java.util.Scanner;

public class FindNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Random r = new Random();
		int num = r.nextInt(3)+1;
		Scanner s = new Scanner(System.in);
		
		for(int i = 0; i<3; i++) {
			System.out.print("숫자를 입력해주세요");
			int a = s.nextInt();
			if(num == a) {
				System.out.println("정답");
			}else {
				System.out.println("틀림");
			}
		}
	}

}
