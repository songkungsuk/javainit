package p01;

public class Condition {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int age = 10;
		Boolean hi = false;
		if (hi) {
			System.out.println("11살");
		}else if(age == 10) {
			System.out.println("11살이 아닙니다");
		}else if(age == 10) {
			System.out.println("11살이 아닙니다1");
		}else if(age == 10) {
			System.out.println("11살이 아닙니다2");
		}
	}

}
