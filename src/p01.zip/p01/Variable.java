package p01;

public class Variable {

	public static void main(String[] args) {
		int a;
		a = 1;
		System.out.println(a);
		int b; // 선언만하고 초기화를 안하면 출력문이 실행이안됨
		//System.out.println(b);
	}
}
