package p01;

import java.util.Scanner;

public class DataType2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String name = "1234";
		System.out.println(name.length());
		System.out.println(name.substring(1));
		System.out.println(name.substring(1, 3));
		int idx = name.indexOf("3");
		System.out.println(idx);
		int id = name.indexOf("6");
		System.out.println(id);
		
		Scanner scanner = new Scanner(System.in);
		

		
		
	}

}
