package p01;

public class DataType {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char a = '1';
		int i = 1;
		byte b = 1;
		short s;
		long l = 10000000000L; //자바에서는 숫자를 그냥쓰면 int로 인식하므로 L을써서 다른타입이라는것이라고 인식시켜준다
		float f = 1.1F;
		boolean bl = true;
	}

}
